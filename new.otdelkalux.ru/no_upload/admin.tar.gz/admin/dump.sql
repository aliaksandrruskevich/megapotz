-- MySQL dump 10.13  Distrib 5.5.24, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: otdelka
-- ------------------------------------------------------
-- Server version	5.5.24-0ubuntu0.12.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `arc_roles`
--

DROP TABLE IF EXISTS `arc_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arc_roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arc_roles`
--

LOCK TABLES `arc_roles` WRITE;
/*!40000 ALTER TABLE `arc_roles` DISABLE KEYS */;
INSERT INTO `arc_roles` VALUES (1,'администратор',NULL),(2,'редактор',NULL);
/*!40000 ALTER TABLE `arc_roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `objects`
--

DROP TABLE IF EXISTS `objects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `objects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) DEFAULT NULL,
  `template` varchar(255) DEFAULT NULL,
  `sort` int(11) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `seo_status` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `date` timestamp NULL DEFAULT NULL,
  `date_of_add` timestamp NULL DEFAULT NULL,
  `last_modified` timestamp NULL DEFAULT NULL,
  `description` text,
  `title` text,
  `seo_title` text,
  `seo_keywords` text,
  `seo_description` text,
  `show_in_main` tinyint(1) NOT NULL DEFAULT '0',
  `work_date` varchar(255) DEFAULT NULL,
  `lat` varchar(50) DEFAULT NULL,
  `lng` varchar(50) DEFAULT NULL,
  `cost` varchar(50) DEFAULT NULL,
  `repair_class` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `picasa_album_id` varchar(255) DEFAULT NULL,
  `picasa_user_id` varchar(255) DEFAULT NULL,
  `area` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `objects_fk_1` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `objects`
--

LOCK TABLES `objects` WRITE;
/*!40000 ALTER TABLE `objects` DISABLE KEYS */;
INSERT INTO `objects` VALUES (1,1,NULL,1,0,'asdasdasd',NULL,1,'2012-08-29 20:00:00',NULL,NULL,'<p>&nbsp;выа выфавыфа вы авфыа фыва ыфва фывафыва ывфа выфафы</p>','супер квартира','пи вапивапривап',' вапывпывап ывап ывап вап ыв','ап ывап выапывап ывапыв',0,'21 января','55.862879','37.009303','231412',1,'https://lh5.googleusercontent.com/-u0CvAjW8bmk/UAhAWCy8fkI/AAAAAAAABFA/SCm7GS25k1I/s50-c/','','',''),(2,0,NULL,2,0,'dominanta',NULL,1,'2012-08-30 20:00:00',NULL,NULL,'','Ремонт квартиры в ЖК «Доминанта»','','','',1,'c 25 января до 31 декабря','','','300',0,'https://lh5.googleusercontent.com/-u0CvAjW8bmk/UAhAWCy8fkI/AAAAAAAABFA/SCm7GS25k1I/s50-c/','5766938084948272737','','230'),(3,0,NULL,1,0,'tarasovka',NULL,1,'2012-08-30 20:00:00',NULL,NULL,'<p>Квартира находится на станции Щукинская в ЖК &quot;Доминанта&quot;.  Все черновые работы проводились с нуля, потому что в новостройке никакого ремонта при строительстве предусмотрено не было.  Перечень работ: установка перегородок, прокладка электрических проводов, сантехнических труб, штукатурка стен, заливка стяжки пола, гипсокартонные потолки, чистовая отделка, установка электрооборудования, установка сантехники, ну и конечно же запуск квартиры в эксплуатацию.  Заказчик остался доволен и, сразу после завержшения работ, доверил нам ремонт загородного дома на Истре.</p>','Ремонт коттеджа в посёлке Тарасовка','','','',1,'25 сентября','','','120 рублей',2,'https://lh5.googleusercontent.com/-u0CvAjW8bmk/UAhAWCy8fkI/AAAAAAAABFA/SCm7GS25k1I/s50-c/','5766943203098445761','','400'),(4,0,NULL,3,0,'greenhell',NULL,1,'2012-09-02 20:00:00',NULL,NULL,'','Отделка коттеджа №14 в посёлке Грин Хилл','','','',0,'c 25 января до 31 декабря','','','300',1,'https://lh5.googleusercontent.com/-u0CvAjW8bmk/UAhAWCy8fkI/AAAAAAAABFA/SCm7GS25k1I/s50-c/','5766924534629363441','','950'),(5,2,NULL,NULL,0,'linker',NULL,1,'2012-09-02 20:00:00',NULL,NULL,'<p>&nbsp;сделано на 500%</p>','Недоделанная','','','',0,'','55.895301','37.064235','',1,'https://lh5.googleusercontent.com/-u0CvAjW8bmk/UAhAWCy8fkI/AAAAAAAABFA/SCm7GS25k1I/s50-c/','','','');
/*!40000 ALTER TABLE `objects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `reg_date` bigint(20) DEFAULT NULL,
  `last_login_date` bigint(20) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `login` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `blocked` tinyint(1) NOT NULL DEFAULT '0',
  `role_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `users_fk_1` (`role_id`),
  CONSTRAINT `users_fk_1` FOREIGN KEY (`role_id`) REFERENCES `arc_roles` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,2012,'admin','admin','111111','admin@gmail.com',0,1);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-09-03 15:23:15


CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `width` varchar(255) DEFAULT NULL,
  `height` varchar(255) DEFAULT NULL,
  `album_id` varchar(255) DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `tag` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=1;