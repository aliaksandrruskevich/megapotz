var object_edited=false;
// ---- start document ready ------
$(document).ready(function() {
	$('#save').live('click',function(){
		$(this).parents('form').submit();
	});

	$('#log_in').click(function(){
			$('#login-form').submit();
	});

    $('#cont').live('click',function(){
		$('#cont').addClass('active_menu');
        $('#users').removeClass('active_menu');
	});

    $('#users').live('click',function(){
        $('#cont').removeClass('active_menu');
        $('#users').addClass('active_menu');
	});

	$('#show_seo').live('click',function(){
		$('#show_properties, #show_content').removeClass('active');
		$('#seo').show();
		$('#show_seo').addClass('active');
		$('#right_column, #edit_text, #properties').css("display","none");
	});

	$('#show_properties').live('click',function(){
		$('#show_seo, #show_content').removeClass('active');
		$('#properties').show();
		$('#show_properties').addClass('active');
		$('#right_column, #edit_text, #seo').css("display","none");
	});

	$('#show_content').live('click',function(){
		$('#show_properties, #show_seo').removeClass('active');
		$('#show_content').addClass('active');
		$('#right_column, #edit_text').show();
		$('#properties, #seo').css('display','none');
	});


	$("#add_prop").live("click", function() {
		var params={
						text: "<h1>Тут будет форма добавления свойства</h1>",
						height: "300",
						width: "400",
						title: "Добавление свойства"
						//close: true
						//close_time: 5
					}
		create_popup(params);
	});

	$("#pop_close").live('click',function(){
		remove_popup();
	})
	
	$("a[rel=ajax]").live("click", function() {
		var url=$(this).attr("href");
		ajax_href(url);
		return false;
	});
	
	$("#page_form input, #page_form textarea, #page_form select").live('change',function(){
	  object_edited=true;
	});

});

function save_data_confirm()
{
  if(object_edited==true && $("#page_form").length>0 ) {
	if(confirm("Изменения не сохранены, вы действительно хотите перейти на редактирование другого языка без сохранения?")) {
	  return true;
	}
	else {
	  return false;
	}
  }
}
// ---- end document ready ------

function ajax_href(url) {
	$.ajax({
    type: "POST",
    url: url,
    success: function(data){
			var params={
							text: data,
							height: "300",
							width: "400",
							title: ""
							//close: true
							//close_time: 5
						}
			create_popup(params);
    }
	});
}


function create_popup(params) {

	params = params || {};

	var height = params.height || 384;
	var width = params.width || 408;

	var title = params.title || "";
	var text = params.text || "";
	var close = params.close || false;
	var close_time = params.close_time || 3;

	if ($("#popup_bg").attr("id")!="popup_bg"){
		$("body").prepend('<div id="popup_bg"></div><div id="popup"></div>');

		$("#popup").css({
			"min-height": height,
			"position":"absolute",
			"min-width": width
		});

	$("#popup").html('<div>'+
				'<div id="topleft" class="top_corner"></div>'+
				'<div id="topright" class="top_corner"></div>'+
				'<div id="top">'+title+'<div id="pop_close"></div></div>'+
				'<div>'+
					'<div id="pop_left"> <div id="pop_right"> <div id="popup_text">'+text+'</div> </div> </div>'+
				'</div>'+
				'<div>'+
					'<div class="bottom_corner" id="bottomleft"></div>'+
					'<div class="bottom_corner" id="bottomright"></div>'+
					'<div class="bottom"></div>'+
				'</div>');

		/*
		 * ставим по центру
		 */

		var windowWidth = document.documentElement.clientWidth;
		var windowHeight = document.documentElement.clientHeight;

		height=$("#popup").height();
		width=$("#popup").width();

		//alert(windowHeight+"-"+height+"-"+document.body.scrollTop);
		$("#popup_bg").css({
			"height": $(document).height(),
			"width": $(document).width()
		});
		$("#popup").css({
			"top": (windowHeight-height)/2 + document.body.scrollTop,
			"left": windowWidth/2-width/2
		});
		$("#popup_bg,#popup").fadeIn(300);
		if(close==true) {
			setTimeout("remove_popup()", close_time*1000);
		}
		
	}

}
    function send_password (){
		$.ajax({
          type: "POST",
          url: 'users/sendpassword',
          success: function(data){$("#err_message").html(data);}});
	}

function remove_popup() {
	$("#popup").fadeOut(300, function () {
		$("#popup_bg,#popup").remove();
	});
}