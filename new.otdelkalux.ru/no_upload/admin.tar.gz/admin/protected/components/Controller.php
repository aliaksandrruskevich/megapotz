<?php

class Controller extends CController
{
	public $lt_menu='objs';
    public $menu=array();
	public $breadcrumbs=array();
    private $_pageTitle = Null;

	public function filters()
	{
		return array(
			'accessControl',
		);
	}

	public function DateToTtamp($value)
	{
		
        $date = explode('.',$value);
        return date('Y-m-d', mktime(0,0,0,$date[1],$date[0],$date[2]));
	}

	public function TtampToDate($value)
	{
        $elements=explode(' ', $value);
        $date = explode('-',$elements[0]);
        $time = explode(':',$elements[1]);
		return ($value) ? date('d.m.Y', mktime(0,0,0,$date[1],$date[2],$date[0])) : Null;
	}

    public function TtampToDateWithTime($value)
	{
        $elements=explode(' ', $value);
        $date = explode('-',$elements[0]);
        $time = explode(':',$elements[1]);
		return ($value) ? date('d.m.Y H:i', mktime($time[0],$time[1],$time[2],$date[1],$date[2],$date[0])) : Null;
	}

    public function AddPeriod ($value, $period)
    {
        $date = explode('.',$value);
        return ($value) ? date('d.m.Y', mktime(0,0,0,$date[1],$date[0],$date[2]+$period)): Null;
    }

    public function getPageTitle() {
		if($this->_pageTitle!==null)
			return $this->_pageTitle;
		else {
			$name=ucfirst(basename($this->getId()));
			if($this->getAction()!==null && strcasecmp($this->getAction()->getId(),$this->defaultAction))
				return $this->_pageTitle=Yii::app()->name.' - '.Yii::t('lan', $name).' - '.Yii::t('lan', ucfirst($this->getAction()->getId()));
			else
				return $this->_pageTitle=Yii::app()->name.' - '.Yii::t('lan', $name);
		}
	}

    public function setPageTitle($value){
		$this->_pageTitle=Yii::app()->name.' - '.$value;
	}
    
     function generatePassword($number)
    {
        $arr = array('a','b','c','d','e','f',
                     'g','h','i','j','k','l',
                     'm','n','o','p','r','s',
                     't','u','v','x','y','z',
                     'A','B','C','D','E','F',
                     'G','H','I','J','K','L',
                     'M','N','O','P','R','S',
                     'T','U','V','X','Y','Z',
                     '1','2','3','4','5','6',
                     '7','8','9','0');
        // Генерируем пароль
        $pass = "";
        for($i = 0; $i < $number; $i++)
        {
          // Вычисляем случайный индекс массива
          $index = rand(0, count($arr) - 1);
          $pass .= $arr[$index];
        }
        return $pass;
  }

  public function getThemeList ()
  {
	$dir='../themes';
	$arr = scandir($dir);
	$list=array();
	$list['не выбрана']='не выбрана';
	foreach ($arr as $item)
	{
	  $pos=strpos($item,'.');
	  if($pos===false)
		$list[$item]=$item;
	}
	return $list;
  }

}