<?php

class UserIdentity extends CUserIdentity
{
  private $_id;

	public function authenticate($md5=true)
    {
        $user=Users::model()->find('LOWER(login)=:login AND blocked=:blocked',array(':login'=>strtolower($this->username),':blocked'=>0));
        if($user===null)
            $this->errorCode=self::ERROR_USERNAME_INVALID;
        //else if((($md5)?md5($this->password):$this->password)!==$user->password)
        else if(($this->password)!==$user->password)
            $this->errorCode=self::ERROR_PASSWORD_INVALID;
        else
        {
            $this->_id=$user->id;
            switch ($user->role_id) {
               case 1: $role = 'admin'; break;
               case 2: $role = 'editor'; break;
               default: $role = 'guest';
            }
            $this->setState('name', $user->name);
            $this->setState('username', $user->login);
            $this->setState('password', $user->password);
            $this->setState('role', $role);
            //$this->setState('title', $user->user_fio);
            //$this->setState('status', $user->user_type);
            $this->errorCode=self::ERROR_NONE;
        }
        return !$this->errorCode;
    }

	 public function getId()
    {
        return $this->_id;
    }
}