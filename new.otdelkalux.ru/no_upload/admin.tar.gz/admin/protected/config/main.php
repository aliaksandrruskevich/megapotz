<?php

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
return array(
	'basePath'=>dirname(__FILE__).DIRECTORY_SEPARATOR.'..',
	'name'=>'CMS Админка',
	'sourceLanguage'=>'ru',
    'defaultController' => 'objects',
	// preloading 'log' component
	'preload'=>array('log'),

	// autoloading model and component classes
	'import'=>array(
		'application.models.*',
		'application.components.*',
		'application.helpers.*',
	),

	'modules'=>array(
		// uncomment the following to enable the Gii tool
		
		'gii'=>array(
			'class'=>'system.gii.GiiModule',
			'password'=>'111111',
		 	// If removed, Gii defaults to localhost only. Edit carefully to taste.
			//'ipFilters'=>array('127.0.0.1','::1'),
		),
		
	),

	// application components
      'components'=>array(
		'user'=>array(
			'allowAutoLogin'=>true,
			'stateKeyPrefix'=>'member',
            /*'class' => 'WebUser',*/
		),

		'clientScript' => array(
       'scriptMap' => array(
            'jquery-ui.css' => '/admin/css/uitheme/custom/jquery-ui-1.8.20.custom.css',
       ),
		),
		// uncomment the following to enable URLs in path-format
		'widgetFactory' => array(
            'widgets' => array(
                'CJuiAccordion' => array(
                  'themeUrl' => '/admin/css/jqueryui',
                  'theme' => 'my',
                  'cssFile'=>'jquery-ui.css'
                   ),
            ),),

		'urlManager'=>array(
			'urlFormat'=>'path',
			'rules'=>array(
				'gii'=>'gii',
				'gii/<controller:\w+>'=>'gii/<controller>',
				'gii/<controller:\w+>/<action:\w+>'=>'gii/<controller>/<action>',
				'<controller:\w+>/<id:\d+>'=>'<controller>/view',
				'<controller:\w+>/<action:\w+>/<id:\d+>'=>'<controller>/<action>',
				'<controller:\w+>/<action:\w+>'=>'<controller>/<action>',
			),
        'showScriptName'=>false
		),
		
		/*'db'=>array(
			'connectionString' => 'sqlite:'.dirname(__FILE__).'/../data/testdrive.db',
		),*/
		// uncomment the following to use a MySQL database
		
		'db'=>array(
			'connectionString' => 'mysql:host=u221902.mysql.masterhost.ru;dbname=u221902',
			'emulatePrepare' => true,
			'username' => 'u221902_2',
			'password' => 'cro5erinea9',
			'charset' => 'utf8',
		),

        'email'=>array(
        'class'=>'application.extensions.yii-mail',
        'delivery'=>'php',
		),

        /*'authManager' => array(
        'class' => 'PhpAuthManager',
        'defaultRoles' => array('guest'),
        ),*/
      
		'errorHandler'=>array(
			// use 'site/error' action to display errors
            'errorAction'=>'site/error',
        ),
		'log'=>array(
			'class'=>'CLogRouter',
			'routes'=>array(
				array(
					'class'=>'CFileLogRoute',
					'levels'=>'error, warning',
				),
				// uncomment the following to show log messages on web pages
		
				array(
					'class'=>'CWebLogRoute',
				),
			
			),
		),
	),

	// application-level parameters that can be accessed
	// using Yii::app()->params['paramName']
	'params'=>array(
		// this is used in contact page
		'adminEmail'=>'webmaster@example.com',
	),

	
);
