<?php

class UsersController extends Controller
{
	public $lt_menu='manage';

    public function accessRules()
	{
    $isAdmin = "isset(Yii::app()->user->role) && (Yii::app()->user->role==='admin')";
    $isEditor = "isset(Yii::app()->user->role) && (Yii::app()->user->role==='editor')";
		return array(
			array('allow',
              'users'=>array('@'),
              'expression' =>$isAdmin,
			),
            array('allow',
              'actions'=>array('index'),
              'users'=>array('@'),
              'expression' =>$isEditor,
			),
			array('deny',
				'users'=>array('*'),
              ),
		);
	}

	public function actionCreate()
	{
		$model=new Users();

		// Uncomment the following line if AJAX validation is needed
//		$this->performAjaxValidation($model);

		if(isset($_POST['Users']))
		{
			$model->attributes=$_POST['Users'];
			if($model->save())
				$this->redirect(array('index','id'=>$model->id));
		}

		$this->renderPartial('create',array('model'=>$model,));
	}

	public function actionUpdate($id)
	{
		$model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Users']))
		{
			$model->name=$_POST['Users']['name'];
            $model->login=$_POST['Users']['login'];
            $model->email=$_POST['Users']['email'];
            $model->role_id=$_POST['Users']['role_id'];
			if($model->save())
				$this->redirect(array('index','id'=>$model->id));
		}

		$this->renderPartial('update',array('model'=>$model));
	}

	public function actionDelete($id)
	{
		if(Yii::app()->request->isPostRequest)
		{
			// we only allow deletion via POST request
			$this->loadModel($id)->delete();

			// if AJAX request (triggered by deletion via admin grid view), we should not redirect the browser
			if(!isset($_GET['ajax']))
				$this->redirect(isset($_POST['returnUrl']) ? $_POST['returnUrl'] : array('admin'));
		}
		else
			throw new CHttpException(400,'Invalid request. Please do not repeat this request again.');
	}

	public function actionSendPassword()
	{
        $model = $this->loadModel($id);
        $name = $model->name;
        $email = $model->email;
        $pass = $this->generatePassword(6);
        $model->password=$pass;
        $model->save();
        $to  = "<".$email.">, " ;
        $subject = "Новый пароль для доступа к bileton.ru";
        $message = '
        <html>
            <head>
                <title>Пароль изменен</title>
            </head>
            <body>
                 <h3>Пароль восстановлен</h3>
                  <p>Используйте следующие данные, чтобы зайти на bileton.ru:</p>
                  <p>Ваш логин: '.$name.'</p>
                  <p>Ваш новый пароль: '.$pass.'</p>
                  <p>Вы можете изменить этот пароль в своём профил.</p>
             </body>
        </html>';

        $headers  = "Content-type: text/html; charset=utf-8 \r\n";
        $headers .= "From: <bileton@info.com>\r\n";
        mail($to, $subject, $message, $headers);
        /*$email = Yii::app()->email;
        $email->to = $email;
        $email->subject = "Новый пароль для доступа к bileton.ru";
        $email->message = '<html>
            <head>
                <title>Пароль изменен</title>
            </head>
            <body>
                 <h3>Пароль восстановлен</h3>
                  <p>Используйте следующие данные, чтобы зайти на bileton.ru:</p>
                  <p>Ваш логин: '.$name.'</p>
                  <p>Ваш новый пароль: '.$pass.'</p>
                  <p>Вы можете изменить этот пароль в своём профил.</p>
             </body>
        </html>';
        $email->send();
        другой способ
        $message = new YiiMailMessage;
        $message->view = 'email_change_pass';
        $message->setBody(array('name'=>$name,'pass'=>$pass), 'text/html');
        $message->addTo($email);
        $message->from = Yii::app()->params['adminEmail'];
        Yii::app()->mail->send($message);*/

        echo 'Ваш пароль отправлен на почту';
	}

	public function actionAdmin()
	{
		$model=new Users('search');
		$model->unsetAttributes();  // clear any default values
		if(isset($_GET['Users']))
			$model->attributes=$_GET['Users'];

		$this->render('admin',array(
			'model'=>$model,
		));
	}
	
	public function actionIndex($block=0)
	{
        if ($type==2){Controller::setPageTitle('Активные пользователи');} else Controller::setPageTitle('Заблокированные пользователи');
        $model=new Users ('search');
		$model->unsetAttributes();  // clear any default values
        if(isset($_GET['Objects']))
		  $model->attributes=$_GET['Objects'];

        // для кнопки вернутся назад
        $attrs=$_GET['Objects'];
        $attrs['block']=$block;
        $session=new CHttpSession;
        $session->open();
        $session['back_url']=$this->createUrl('users/index',$attrs);
        
		$this->render('index',array(
			'block'=>$block, 'model'=>$model,
		));
	}

	public function loadModel($id)
	{
		$model=Users::model()->findByPk($id);
		if($model===null)
			throw new CHttpException(404,'The requested page does not exist.');
		return $model;
	}

//	protected function performAjaxValidation($model)
//	{
//		if(isset($_POST['ajax']) && $_POST['ajax']==='users-form')
//		{
//            $model->setScenario('ajax');
//			echo CActiveForm::validate($model);
//			Yii::app()->end();
//		}
//	}

    public function actionBlock ($id)
    {
        $model = $this->loadModel($id);
        $model->blocked = 1;
        $model->save();
        $this->redirect(Yii::app()->session['back_url']);
    }

    public function actionUnblock ($id)
    {
        $model = $this->loadModel($id);
        $model->blocked = 0;
        $model->save();
        $this->redirect(Yii::app()->session['back_url']);
    }

    public function actionChangepass ($id)
    {
        $model=$this->loadModel($id);

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

		if(isset($_POST['Users']))
		{
			if (!empty($_POST['Users']['password']))
              $model->password=$_POST['Users']['password'];
			if($model->save())
				$this->redirect(array('index','id'=>$model->id));
		}

		$this->renderPartial('change_pass',array(
			'model'=>$model,
		));
    }

}
