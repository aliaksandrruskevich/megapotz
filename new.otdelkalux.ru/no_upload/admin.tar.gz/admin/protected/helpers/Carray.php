<?php
class Carray {

	function parents2list($data=array(),$break="<br/>") {
		$return=array();
		foreach($data as $row) {
			$return[]=$row->title;
		}
		return implode($break,$return);
	}

}
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
