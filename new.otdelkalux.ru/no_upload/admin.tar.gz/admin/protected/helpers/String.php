<?php
class String {

	function htmlquotes($str) {
		$str=str_replace('"', '&quot;', $str);
		$str=str_replace("'", '&apos;', $str);
		$str=str_replace('\\', "\\\\", $str);
		return $str;
	}

}
/* 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

?>
