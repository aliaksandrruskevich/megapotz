<?php

class ArcRoles extends CActiveRecord
{

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function tableName()
	{
		return 'arc_roles';
	}

	public function rules()
	{
		return array(
			array('name, description', 'length', 'max'=>255),
			array('id, name, description', 'safe', 'on'=>'search'),
		);
	}

	public function relations()
	{
		return array(
			'users' => array(self::HAS_MANY, 'Users', 'role_id'),
		);
	}

	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
		);
	}

	public function search()
	{
		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

    public function selectItems ()
    {
        $model = ArcRoles::model()->findAll();
        $items = array();
        foreach ($model as $row)
        {
            $items[$row->id] = $row->name;
        }
        return $items;
    }

     public function filterItems ()
    {
        $model = ArcRoles::model()->findAll();
        $items = array();
        $items[0]="Все";
        foreach ($model as $row)
        {
            $items[$row->id] = $row->name;
        }
        return $items;
    }

}