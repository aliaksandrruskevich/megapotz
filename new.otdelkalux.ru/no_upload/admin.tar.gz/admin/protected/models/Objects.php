<?php

/**
 * This is the model class for table "objects".
 *
 * The followings are the available columns in table 'objects':
 * @property integer $id
 * @property integer $type
 * @property string $template
 * @property integer $sort
 * @property integer $status
 * @property string $link
 * @property integer $seo_status
 * @property integer $user_id
 * @property string $date
 * @property string $date_of_add
 * @property string $last_modified
 * @property string $html
 * @property string $title
 * @property string $description
 * @property string $seo_title
 * @property string $seo_keywords
 * @property string $seo_description
 * @property integer $show_in_main
 * @property integer $picasa_user_id
 * @property integer $picasa_album_id
 * @property string $work_date
 * @property string $lat
 * @property string $lng
 * @property string $cost
 * @property integer $repair_class
 */
class Objects extends CActiveRecord
{
	/**
	 * Returns the static model of the specified AR class.
	 * @param string $className active record class name.
	 * @return Objects the static model class
	 */
  
    public $picasa_images="";
	public $picasa_user_id="104094916837036848285";
	
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'objects';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array ('title, link','required'),
			array('type, sort, status, seo_status, user_id, show_in_main, picasa_user_id, picasa_album_id, repair_class', 'numerical', 'integerOnly'=>true),
			array('template, link, work_date, image, area', 'length', 'max'=>255),
			array('lat, lng, cost', 'length', 'max'=>50),
			array('date, date_of_add, last_modified, title, description, seo_title, seo_keywords, seo_description, image', 'safe'),
			// The following rule is used by search().
			// Please remove those attributes that should not be searched.
			array('id, type, template, sort, status, area, link, image, seo_status, user_id, date, date_of_add, last_modified, title, description, seo_title, seo_keywords, seo_description, show_in_main, picasa_user_id, picasa_album_id, work_date, lat, lng, cost, repair_class', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'type' => 'Cтатус работы',
			'template' => 'Template',
			'sort' => 'Сортировка (число)',
			'status' => 'Не показывать на сайте',
			'link' => 'Ссылка',
			'seo_status' => 'Seo Status',
			'user_id' => 'User',
			'date' => 'Дата',
			'date_of_add' => 'Date Of Add',
			'last_modified' => 'Last Modified',
			'title' => 'Название',
			'description' => 'Описание',
			'seo_title' => 'Seo Title',
			'seo_keywords' => 'Seo Keywords',
			'seo_description' => 'Seo Description',
			'show_in_main' => 'Показывать на главной',
			'picasa_user_id' => 'Picasa User ID',
			'picasa_album_id' => 'Picasa Album ID',
			'work_date' => 'Дата проведения работы',
			'lat' => 'Координаты(широта)',
			'lng' => 'Координаты(долгота)',
			'cost' => 'Цена',
			'repair_class' => 'Тип работы',
			'image' => 'Ссылка на картинку',
			'area' => 'Площадь',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 * @return CActiveDataProvider the data provider that can return the models based on the search/filter conditions.
	 */
	public function search($type=0)
	{
		// Warning: Please modify the following code to remove attributes that
		// should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id);
		$criteria->compare('type',$this->type);
		$criteria->compare('template',$this->template,true);
		$criteria->compare('sort',$this->sort);
		$criteria->compare('status',$this->status);
		$criteria->compare('link',$this->link,true);
		$criteria->compare('seo_status',$this->seo_status);
		$criteria->compare('user_id',$this->user_id);
		$criteria->compare('date',$this->date,true);
		$criteria->compare('date_of_add',$this->date_of_add,true);
		$criteria->compare('last_modified',$this->last_modified,true);
		$criteria->compare('title',$this->title,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('seo_title',$this->seo_title,true);
		$criteria->compare('seo_keywords',$this->seo_keywords,true);
		$criteria->compare('seo_description',$this->seo_description,true);
		$criteria->compare('show_in_main',$this->show_in_main);
		$criteria->compare('picasa_user_id',$this->picasa_user_id);
		$criteria->compare('picasa_album_id',$this->picasa_album_id);
		$criteria->compare('work_date',$this->work_date,true);
		$criteria->compare('lat',$this->lat,true);
		$criteria->compare('lng',$this->lng,true);
		$criteria->compare('cost',$this->cost,true);
		$criteria->compare('repair_class',$this->repair_class);

		if ($type==1)
		{
		  $criteria->addColumnCondition(array('type'=>1));
		}
		elseif($type==2)
		{
		  $criteria->addColumnCondition(array('type'=>2));
		}
		elseif($type==3)
		{
		  $criteria->addColumnCondition(array('type'=>3));
		}
		else
		{
		  $criteria->addColumnCondition(array('type'=>0));
		}
			
		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
			'sort'=>array('defaultOrder' => 'sort')
		));
	}
	
	function get_count($type=false) {
	
	  if($type==0)
		$request="AND (type=0 OR type IS NULL OR type=3)";
	  else 
		$request="AND (type=1 OR type=2)";
	  $query = Yii::app()->db->createCommand("SELECT COUNT(*) FROM objects WHERE (status=0 OR status is NULL) $request");
	  $count = $query->queryScalar();
	  return (int)$count;
	}
	
	protected function afterFind()
	{
	
		$this->title=String::htmlquotes($this->title);
		$this->description=String::htmlquotes($this->description);
		$this->work_date=String::htmlquotes($this->work_date);
		$this->seo_title=String::htmlquotes($this->seo_title);
		$this->seo_keywords=String::htmlquotes($this->seo_keywords);
		$this->description=String::htmlquotes($this->description);
		parent::afterFind();
	}
}