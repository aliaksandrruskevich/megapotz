<?php

class Users extends CActiveRecord
{
    public $blocked;

	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}

	public function tableName()
	{
		return 'users';
	}

	public function rules()
	{
		return array(
            array ('login, password, email','required'),
			array('blocked, role_id', 'numerical', 'integerOnly'=>true),
			array('last_login_date', 'length', 'max'=>20),
            array('password', 'length', 'min'=>6),
            array('login', 'unique','message'=>'Логин занят'),
            array ('email','email'),
			array('login, password, email, name', 'length', 'max'=>255),
			array('reg_date', 'safe'),
			array('id, reg_date, last_login_date, name, login, password, email, blocked, role_id', 'safe', 'on'=>'search'),
		);
	}

	public function relations()
	{
		return array(
			'objects' => array(self::HAS_MANY, 'Objects', 'user_id'),
			'role' => array(self::BELONGS_TO, 'ArcRoles', 'role_id'),
		);
	}

	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'reg_date' => 'Дата регистрации',
			'last_login_date' => 'Посл. посещение',
            'name'=>'Имя',
			'login' => 'Логин',
			'password' => 'Пароль',
			'email' => 'Эл. почта',
			'blocked' => 'Блокирован',
			'role_id' => 'Роль',
            'role'=>'Роль',
            'rememberMe'=>'запомнить меня'
		);
	}

	public function search($block=0)
	{
		$criteria=new CDbCriteria;

        $criteria->compare('name',$this->name,true);
		$criteria->compare('login',$this->login,true);
		$criteria->compare('email',$this->email,true);
		$criteria->compare('blocked',$this->blocked);
		$criteria->compare('role_id',$this->role_id);

        if (!empty($this->reg_date))
		{
		  $date=Controller::DateToTtamp($this->reg_date);
		  $condition[]='reg_date LIKE "'.$date.'%" ';
		}
		if (!empty($this->last_login_date))
		{
		  $date=Controller::DateToTtamp($this->last_login_date);
		  $condition[]=' last_login_date LIKE "'.$date.'%" ';
		}
		if(!empty($condition))
		$criteria->condition=implode("AND",$condition);

        if ($block==1)
        $criteria->addColumnCondition(array('blocked'=>1));

        if ($block==2)
          $criteria->addColumnCondition(array('blocked'=>0));

        $sort = new CSort();
        $sort->defaultOrder = 't.name DESC';
        $sort->attributes = array(
            'name'=>array(
                'asc'=>'t.name asc',
                'desc'=>'t.name desc',
            ),
            'login'=>array(
                'asc'=>'t.login desc',
                'desc'=>'t.login asc',
            ),
            'email'=>array(
                'asc'=>'t.email desc',
                'desc'=>'t.email asc',
            ),
            'role.name'=>array(
                'asc'=>'role.name desc',
                'desc'=>'role.name asc',
            ),
            'reg_date'=>array(
                'asc'=>'t.reg_date desc',
                'desc'=>'t.reg_date asc',
            ),
            'last_login_date'=>array(
                    'asc'=>'t.last_login_date desc',
                    'desc'=>'t.last_login_date asc',
                ),
            '*',
        );

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,'sort'=>$sort,'pagination'=>array('pageSize'=>10,),));
	}

    /*protected function beforeSave()
	{
		if(parent::beforeSave())
		{
			$this->password = md5($this->password);
        return true;
			}
		else
			return false;
	 }*/
}