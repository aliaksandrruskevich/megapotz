<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href='http://fonts.googleapis.com/css?family=Ubuntu:400,500&subset=latin,cyrillic-ext' rel='stylesheet' type='text/css'/>
	<link rel="stylesheet" type="text/css" href="<?php echo Yii::app()->request->baseUrl; ?>/css/style.css" />
	<?php  Yii::app()->clientScript->registerCoreScript('jquery.ui'); ?>
	<?php  Yii::app()->clientScript->registerScriptFile(Yii::app()->request->baseUrl.'/js/main.js');?>
    <?Yii::app()->clientScript->registerScript(
   'myHideEffect',
   '$(".info").animate({opacity: 1.0}, 3000).fadeOut("slow");',
   CClientScript::POS_READY
);?>
	<title><?php echo Controller::getPageTitle(); ?></title>
</head>

  <body>
	<div id="wrapper">
		<div id="top_menu">
		<?php echo CHtml::link('<div id="exit"></div>',array('site/logout')); ?>
		<div id="user_name"><p>Здравствуйте, <?if (!empty(Yii::app()->user->name)) echo Yii::app()->user->name; else Yii::app()->user->username?></p></div>
			<ul class="menu">
			<li <?if ($this->lt_menu=="objs") echo "class=\"item active_menu\""; else echo "class=\"item\""?>><a id="cont" href="<?php echo Yii::app()->request->baseUrl; ?>/objects/?type=1">Контент</a></li>
			<li <?if ($this->lt_menu=="manage") echo "class=\"item active_menu\""; else echo "class=\"item\""?>><a id="manage" href="<?php echo Yii::app()->request->baseUrl; ?>/users/?block=2">Управление</a></li>
			</ul>
		</div>

		<div id="main">
		<div id="lt_menu">
			<div id="lt_menu_container">
            <? if ($this->lt_menu=='objs')
               {
                  $panel=array(
                        'Объекты'=>'<li class="submenu"><a href="'.Yii::app()->request->baseUrl.'/objects/index/?type=0">Завершенные</a></li>
						 <li class="submenu"><a href="'.Yii::app()->request->baseUrl.'/objects/index/?type=1">Черновая отд.</a></li>
						  <li class="submenu"><a href="'.Yii::app()->request->baseUrl.'/objects/index/?type=2">Чистовая отд.</a></li>',
						'Генерация'=>'<li class="submenu"><a href="'.Yii::app()->request->baseUrl.'/site/getImagesXHR">Синхронизировать PICASA</a>
						  <li class="submenu"><a href="'.Yii::app()->request->baseUrl.'/site/generatesite">Сгенерировать страницы</a></li>'
					  );
               }
               if ($this->lt_menu=='manage')
               {
                  $panel=array(
                    'Пользователи'=>'<ul><li class="submenu"><a href="'.Yii::app()->request->baseUrl.'/users/index/?block=2">Активные</a></li>
                                     <li class="submenu"><a href="'.Yii::app()->request->baseUrl.'/users/index/?block=1">Заблокированные</a></li></ul>',
                  );
               }
              $this->widget('zii.widgets.jui.CJuiAccordion', array(
                 'panels'=>$panel,
                 'options'=>array(
                      'animated'=>'slide',
                      'autoHeight'=>False,
                      'navigation'=>True,
                       ),
                  ));?>
            </div>
        </div>
			</div>
		<div id="content_container">
		  <?php echo $content; ?>
		</div>
		</div>
</body>
</html>
