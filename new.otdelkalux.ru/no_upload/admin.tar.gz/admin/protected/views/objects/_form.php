<?
$session=new CHttpSession;
$session->open();
$this->widget('zii.widgets.jui.CJuiButton',
	array(
		'name'=>'button',
		'caption'=>'Вернуться к списку',
		'value'=>'asd',
		'onclick'=>"function (){location.href = '".$session['back_url']."'}",
		)
);?>
<div id="lang">
</div>

<div id="page_area">
	<div id="page_menu">
	<ul>
		<li id="show_content" class="active">Контент</li>
		<li id="show_seo">SEO</li>
	</ul>
	</div>
	<? $form=$this->beginWidget('CActiveForm', array(
		'id'=>'page_form',
		'enableAjaxValidation'=>false,
		'htmlOptions'=>array('enctype'=>'multipart/form-data')
	));
	echo "<div style=\"color: red; display: block; overflow: hidden; padding-left: 32px;\">".$form->errorSummary($model)."</div>";
	if(!empty($variants))
	echo $form->errorSummary($variants);?>

	<div id="page_info">
		<div id="right_column">
			<p>
				<?php echo $form->labelEx($model,'date'); ?><!--&nbsp;&nbsp;&nbsp;<img id="calendar" src="<?=Yii::app()->request->baseUrl?>/images/calendar.png"/>/-->
			</p>
			<?
			if (!empty($model->date))
				$date = $this->TtampToDate($model->date);
			else $date = date('d.m.Y');
			$this->widget('zii.widgets.jui.CJuiDatePicker', array(
				'language'=>Yii::app()->getLanguage(),
				'model'=>$model,
				'attribute'=>'date',
				'options'=>array(
					'dateFormat'=>"dd.mm.yy",
					'showAnim'=>'fold',
					'beforeShow'=>"js:function() {
						$('.ui-datepicker').css('font-size', '0.8em');
						$('.ui-datepicker').css('z-index', parseInt($(this).parents('.ui-dialog').css('z-index'))+1);
						}",
					),
				'htmlOptions'=>array('class'=>'border_st input','value'=>$date))); ?>
			<?php echo $form->error($model,'date'); ?>
			
			<p><?php echo $form->labelEx($model,'type'); ?></p>
			  <?php echo $form->dropDownList($model,'type',array(0=>'Завершенная',1=>'Черновая отделка',2=>'Чистовая отделка',3=>'Ландшафтные работы'),array('empty' => '','options'=>array($model->type=>array('selected'=>'selected'))));	?>
			  <?php echo $form->error($model,'type'); ?>
			<p><?php echo $form->labelEx($model,'cost'); ?></p>
			  <?php echo $form->textField($model,'cost',array('class'=>'border_st input')); ?>
			<p><?php echo $form->labelEx($model,'area'); ?></p>
			  <?php echo $form->textField($model,'area',array('class'=>'border_st input')); ?>
			<p><?php echo $form->labelEx($model,'repair_class'); ?></p>
			 <?php echo $form->dropDownList($model,'repair_class',array(0=>'Стандарт',1=>'Бизнес','Люкс'),array('empty' => '','options'=>array($model->repair_class=>array('selected'=>'selected'))));	?>
			<p><?php echo $form->labelEx($model,'picasa_user_id'); ?></p>
			  <?php echo $form->textField($model,'picasa_user_id',array('class'=>'border_st input')); ?>
			<p><?php echo $form->labelEx($model,'picasa_album_id'); ?></p>
			  <?php echo $form->textField($model,'picasa_album_id',array('class'=>'border_st input')); ?>
			<p><?php echo $form->labelEx($model,'lat'); ?></p>
			  <?php echo $form->textField($model,'lat',array('class'=>'border_st input')); ?>
			<p><?php echo $form->labelEx($model,'lng'); ?></p>
			  <?php echo $form->textField($model,'lng',array('class'=>'border_st input')); ?>
			
			<p>Настройки</p>
			<div class="row">
			  <?php echo $form->checkBox($model,'status',array('value'=>"1")); ?>
			  <?php echo $form->labelEx($model,'status'); ?>
			  <?php echo $form->error($model,'status'); ?>
			</div>
			<div class="row">
			  <?php echo $form->checkBox($model,'show_in_main',array('value'=>"1")); ?>
			  <?php echo $form->labelEx($model,'show_in_main'); ?>
			  <?php echo $form->error($model,'show_in_main'); ?>
			</div>
              
			  <p><?php echo $form->labelEx($model,'sort'); ?></p>
			  <?php echo $form->textField($model,'sort',array('class'=>'border_st input')); ?>
			  
	
		</div>
		<div id="left_column">
			<div id="edit_text">
			<p><? echo $form->labelEx($model,'title'); ?></p>
			<? echo $form->textField($model,'title',array('class'=>"border_st input title","size"=>"81")); ?>
			<? echo $form->error($model,'title'); ?>
			<br />
			<br />
			<p><? echo $form->labelEx($model,'description'); ?></p>
			<? echo $form->textArea($model,'description',array('style'=>"height: 280px")); ?>
			<? echo $form->error($model,'description'); ?>
			
			<p><? echo $form->labelEx($model,'link'); ?></p>
			<? echo $form->textField($model,'link',array('class'=>"border_st input","size"=>"81")); ?>
			<? echo $form->error($model,'link'); ?>
			
			<p><? echo $form->labelEx($model,'work_date'); ?></p>
			<? echo $form->textField($model,'work_date',array('class'=>"border_st input","size"=>"81")); ?>
			<? echo $form->error($model,'work_date'); ?>
			
			<p><? echo $form->labelEx($model,'image'); ?></p>
			<? echo $form->textField($model,'image',array('class'=>"border_st input","size"=>"81")); ?>
			<? echo $form->error($model,'image'); ?>
			
			</div>
			<div id="seo">
				<p><? echo $form->labelEx($model,'seo_title'); ?></p>
				<? echo $form->textArea($model,'seo_title',array('class'=>"border_st",'size'=>"62")); ?>
				<? echo $form->error($model,'seo_title'); ?>
				<p><? echo $form->labelEx($model,'seo_keywords'); ?></p>
				<? echo $form->textArea($model,'seo_keywords',array('class'=>"border_st",'cols'=>"30",'rows'=>"5",'wrap'=>"soft")); ?>
				<? echo $form->error($model,'seo_keywords'); ?>
				<p><? echo $form->labelEx($model,'seo_description'); ?></p>
				<? echo $form->textArea($model,'seo_description',array('class'=>"border_st",'cols'=>"30",'rows'=>"5",'wrap'=>"soft")); ?>
				<? echo $form->error($model,'seo_description'); ?>
			</div>

		</div>
      <div style="height:1px;overflow:hidden;clear:both;"></div>
	</div>
	<?php echo CHtml::linkButton($model->isNewRecord ? 'Создать' : 'Сохранить',array('class'=>'bt','id'=>'save')); ?>
	<? $this->endWidget(); ?>
</div>
