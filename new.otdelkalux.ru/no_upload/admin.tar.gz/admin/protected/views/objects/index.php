<h3><? echo 'Объекты';?></h3>
<?
$name='Создать объект';

$create_url=Yii::app()->request->baseUrl."/objects/create/?type=".intval($type);
$this->widget('zii.widgets.jui.CJuiButton',
	array(
		'name'=>'button',
		'caption'=>$name,
		'value'=>'asd',
		'onclick'=>"function (){location.href = '$create_url'}",
		)
);?>
<div id="lang">
</div>
<?$this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'objects-grid',
    'cssFile'=>Yii::app()->request->baseUrl.'/css/admin_grid.css',
	'dataProvider'=>$model->search($type,$id,$menu,$s),
    'pager' => array(
        'class'=>'CLinkPager',
        'cssFile'=>false,
        'header'=>false,
        'firstPageLabel'=>'<<',
        'prevPageLabel'=>'<пред.',
        'nextPageLabel'=>'след.>',
        'lastPageLabel'=>'>>'),
    'filter'=>$model,
	'columns'=>array(          
         array(
					'name' => 'title',
					'type' => 'raw',
					'value' =>'(!empty($data->status)) ? "<font color=\"#777\">".$data->title."</font>": $data->title',
			),
		array(
					'name' => 'sort',
					'type' => 'raw',
					'value' =>'(!empty($data->status)) ? "<font color=\"#777\">".$data->sort."</font>": $data->sort',
					'htmlOptions' => array('style' => 'width:100px;'),
			),
		array(
					'name' => 'show_in_main',
					'type' => 'raw',
					'value' =>'(!empty($data->status)) ? "<font color=\"#777\">".$data->show_in_main."</font>": $data->show_in_main',
					'htmlOptions' => array('style' => 'width:100px;'),
			),
		array(
			'class'=>'CButtonColumn',
            'template'=>'{update}{hide}{show}{delete}',
			'htmlOptions' => array('style' => 'width:100px;'),
            'buttons'=>array
              (
			  'update' => array
			  (
				  'label'=>'Редактировать',
				  'imageUrl'=>Yii::app()->request->baseUrl.'/images/edit_page.png'
			  ),
			  'hide' => array
			  (
				  'label'=>'Показать на сайте',
				  'imageUrl'=>Yii::app()->request->baseUrl.'/images/bulb-off.png',
				  'url'=>'Yii::app()->request->baseUrl."/objects/show/?id=".$data->id."&type=".$data->type."&par_id=".intval('.$id.')."&s=".intval('.$s.')',
				  'visible'=>'$data->status == 1',
			  ),
			  'show' => array
			  (
				  'label'=>'Скрыть на сайте',
				  'imageUrl'=>Yii::app()->request->baseUrl.'/images/bulb.png',
				  'url'=>'Yii::app()->request->baseUrl."/objects/hide/?id=".$data->id."&type=".$data->type."&par_id=".intval('.$id.')."&s=".intval('.$s.')."&menu=".intval('.$menu.')',
				  'visible'=>'$data->status == 0',
			  ),
			  'delete' => array
			  (
				  'label'=>'Удалить',
				  'imageUrl'=>Yii::app()->request->baseUrl.'/images/deletered.png',
			  ),
    ),
),),
)); ?>
