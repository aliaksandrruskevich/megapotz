<h3><?php echo $model->title; ?></h3>
<div style="float: right; padding-right: 80px;"><?php if(Yii::app()->user->hasFlash('success')):
        echo "<span style=\"font-size:10pt; color:red; font-weight:bold;\" class=\"info\">".Yii::app()->user->getFlash('success')."</span>";
endif; ?></div>

<?php echo $this->renderPartial('_form', array('model'=>$model)); ?>