<h1>Ошибка 403</h1>
<p>У вас не хватает прав доступа, настройка отображения в site/error403 и в siteController метод actionError</p>
<a href="<?=Yii::app()->request->baseUrl?>/site/login">войти</a>