<div class="form">

<?php $form=$this->beginWidget('CActiveForm', array(
	'id'=>'users-form',
	'enableAjaxValidation'=>true,
)); ?>

	<?php echo $form->errorSummary($model); ?>

    <?if ($action=='update' OR $action=='create'){?>
    <p><?php echo $form->labelEx($model,'name'); ?></p>
	<?php echo $form->textField($model,'name',array('maxlength'=>255,'class'=>'field')); }
    else {?>
      <div class="row">
		<p><?php echo $form->labelEx($model,'name'); ?></p>
		<?php echo $model->name; ?>
	</div>
    <?}?>

	<?if ($action=='update' OR $action=='create'){?>
    <p><?php echo $form->labelEx($model,'login'); ?></p>
	<?php echo $form->textField($model,'login',array('maxlength'=>255,'class'=>'field'));}
    else {?>
      <div class="row">
		<p><?php echo $form->labelEx($model,'login'); ?></p>
		<?php echo $model->login; ?>
	</div>
    <?}?>

	<?if ($action=='update' OR $action=='create'){?>
    <p><?php echo $form->labelEx($model,'email'); ?></p>
	<?php echo $form->textField($model,'email',array('maxlength'=>255, 'class'=>'field')); }?>

    <?if ($action=='pass' OR $action=='create'){?>
    <p><?php echo $form->labelEx($model,'password'); ?></p>
	<?php echo $form->passwordField($model,'password',array('maxlength'=>255, 'class'=>'field')); }?>
    Пароль не менее 6 символов

	<?if ($action=='update' OR $action=='create'){?>
    <p><?php echo $form->labelEx($model,'role_id'); ?></p>
	<?php echo $form->dropDownList($model,'role_id',ArcRoles::selectItems(),array('class'=>'field')); }?>

	<p><?php echo CHtml::linkButton($model->isNewRecord ? 'Создать' : 'Сохранить', array('class'=>'bt','id'=>'save','click'=>'return false;')); ?></p>

<?php $this->endWidget(); ?>
</div>
