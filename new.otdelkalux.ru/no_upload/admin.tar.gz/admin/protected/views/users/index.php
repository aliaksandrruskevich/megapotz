<h3><? if ($block==1) echo "Заблокированные пользователи"; elseif ($block==2) echo "Активные пользователи"; else echo "Все пользователи";?></h3>

<? 
$edit_user =<<< EOD
function() { 
		var url=$(this).attr("href");
		ajax_href(url);
		return false; }
EOD;

$create_url=Yii::app()->request->baseUrl."/users/create";
$this->widget('zii.widgets.jui.CJuiButton',
	array(
		'name'=>'button',
		'caption'=>'создать пользователя',
		'value'=>'asd',
		'onclick'=>"function (){ $(\"<div id='mydialog'></div>\").load('$create_url').dialog({title:'Новый пользователь'});return false;}",
		)
);

$this->widget('zii.widgets.grid.CGridView', array(
	'id'=>'users-grid',
    'cssFile'=>Yii::app()->request->baseUrl.'/css/admin_grid.css',
	'dataProvider'=>$model->search($block),
    'pager' => array(
        'class'=>'CLinkPager',
        'cssFile'=>false,
        'header'=>false,
        'firstPageLabel'=>'<<',
        'prevPageLabel'=>'<пред.',
        'nextPageLabel'=>'след.>',
        'lastPageLabel'=>'>>'),
    'filter'=>$model,
	'columns'=>array(
        'name',
        'login',
        'email',
        array(
					'name' => 'role_id',
					'type' => 'raw',
                    'filter'=>false,
                    'filter'=>ArcRoles::selectItems(),
					'value' =>'$data->role->name',
                    'htmlOptions' => array('style' => 'width:130px;'),
			),
        array(
					'name' => 'last_login_date',
					'type' => 'raw',
					'value' =>'Controller::TtampToDateWithTime($data->last_login_date)',
                    'htmlOptions' => array('style' => 'width:100px;'),
			),
		array(
					'name' => 'reg_date',
					'type' => 'raw',
					'value' =>'Controller::TtampToDate($data->reg_date)',
                    'htmlOptions' => array('style' => 'width:100px;'),
			),
		array(
                'class'=>'CButtonColumn',
                'template'=>'{update}{block}{unblock}{password}',
                'buttons'=>array
                 (
                      'update' => array
                       (
                          'label'=>'Редактировать',
                          'imageUrl'=>Yii::app()->request->baseUrl.'/images/edit_page.png',
                          'url'=>'Yii::app()->request->baseUrl."/users/update/".$data->id',
                          'click'=>"function (){ $(\"<div id='mydialog'></div>\").load($(this).attr('href')).dialog({title:'Редактирование'});return false;}",
                       ),
                      'block' =>array
                      (
                          'label'=>'Блокировать',
                          'imageUrl'=>Yii::app()->request->baseUrl.'/images/unlock.png',
                          'url'=>'Yii::app()->request->baseUrl."/users/block/".$data->id',
                          'visible'=>'empty($data->blocked)',
                      ),
                      'unblock' => array
                      (
                          'label'=>'Разблокировать',
                          'imageUrl'=>Yii::app()->request->baseUrl.'/images/lock.png',
                          'url'=>'Yii::app()->request->baseUrl."/users/unblock/".$data->id',
                          'visible'=>'intval($data->blocked) == 1',
                      ),
                      'password'=> array
                      (
                          'label'=>'Сменить пароль',
                          'imageUrl'=>Yii::app()->request->baseUrl.'/images/default_pass.png',
                          'url'=>'Yii::app()->request->baseUrl."/users/changepass/".$data->id',
                          'click'=>"function (){ $(\"<div id='mydialog'></div>\").load($(this).attr('href')).dialog({title:'Редактирование пароля'});return false;}",
                      )
                 ),
          ),
      ),
  )
); ?>
